<?php
// Website name
$themeReplace['site_name'] = 'Maths';
